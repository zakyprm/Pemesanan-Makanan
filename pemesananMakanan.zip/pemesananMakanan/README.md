# Pemesanan Makanan
Web pemesanan ini dibuat dengan ui dan ux yang simple sehingga tidak sulit digunakan

## Run Locally

Clone the project

```bash
  git clone https://github.com/Leon24k/pemesananMakanan.git
```

Go to the project directory

```bash
  cd pemesananMakanan
```

Install dependencies

```bash
  npm install
```

Start the server

```bash
  npm run start
```


## Authors

- [@Leon24k](https://www.github.com/Leon24k)

